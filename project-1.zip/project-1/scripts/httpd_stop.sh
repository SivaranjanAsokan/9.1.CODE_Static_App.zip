#!/bin/bash
systemctl stop httpd
systemctl disable httpd
